% Modulo for one-based indices
function y = mod1(i,N)
    y = mod(i-1,N)+1;
end
